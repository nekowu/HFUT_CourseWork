void buzzer_on();
void buzzer_off();
void buzzer_init(void);