#include "stdio.h"
#include "buzzer.h"
#define GPKCON0 (*(volatile unsigned long *)0x7F008800)
#define GPKDAT (*(volatile unsigned long *)0x7F008808)
#define GPKDATA (*(volatile unsigned long *)0x7F008808)
#define GPNCON (*(volatile unsigned long *)0x7F008830)
#define GPNDAT (*(volatile unsigned long *)0x7F008834)
#define GPFCON (*(volatile unsigned int *)0x7F0080A0)
#define GPFDAT (*(volatile unsigned int *)0x7F0080A4)

#define		PWMTIMER_BASE			(0x7F006000)
#define		TCFG0    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x00)) )
#define		TCFG1    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x04)) )
#define		TCON      	( *((volatile unsigned long *)(PWMTIMER_BASE+0x08)) )
#define		TCNTB0    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x0C)) )
#define		TCMPB0    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x10)) )
#define		TINT_CSTAT 	( *((volatile unsigned long *)(PWMTIMER_BASE+0x44)) )

void timer_init(unsigned long utimer,unsigned long uprescaler,unsigned long udivider,unsigned long utcntb,unsigned long utcmpb);
void init_uart(void);
volatile int pressnum1 = 0;  //统计按键1模式的按下次数
volatile int pressnum3 = 0;  //统计按键3模式的按下次数
volatile int flag_key2 = 0;  //按键2按下标志位
volatile int flag_key3 = 0;  //按键3按下标志位
volatile int flag_key4 = 0;  //按键4按下标志位
volatile int flag_over = 0;  //按键3模式的按键操作结束标志位
volatile int flag_OT = 0;  //按键3模式的按键操作超时标志位
volatile int equal_13 = 0;  //按键3模式的按键次数相等标志位
volatile int flag_firstpress = 0;  //按键3模式的首次按键标志位
volatile int timenum;  //获取按键3模式的计时器时间参数
volatile int key3_times = 0;  //统计按键3模式的计时器执行次数
volatile int sharknum = 0;  //按键2模式的灯闪烁次数
volatile int i = 0;  //控制流水灯的参数

void buzzer_on()
{
	GPFDAT |= 1<<14;
}

void buzzer_off()
{
	GPFDAT &= ~(1<<14);
}

void buzzer_init(void)
{
	GPFCON |= 1<<28;
	GPFCON &= ~(1<<29);
}

void delay(volatile int delaynum)
{
	while(delaynum > 0){
		delaynum--;
	}
}

int main()
{
	int dat;

	GPKCON0 = 0x11110000;	// 配置GPK4-7为输出功能
	GPKDAT = 0x000000f0;  // 所有LED熄灭
	GPNCON = 0;  // 配置GPN为输入功能
	
	init_uart();  //初始化
	buzzer_init();
	
	// 轮询的方式查询按键事件
	while(1)
	{
		dat = GPNDAT;
		
		if(key3_times > 0){
			flag_OT = 1;  //按键超时标志位置1
			flag_over = 1;  //按键结束标志位置1
			if(pressnum3 == pressnum1){  //若按键3次数等于按键1次数
				equal_13 = 1;  //按键相等标志位置1
				timer_init(0,65,4,62500,0);  //设置定时器定时1s
			}else{
				equal_13 = 0;  //按键相等标志位置0
			}
		}

		if(!(dat & (1<<0))){	//按下按键1
			delay(800000);
			pressnum1++;
		}else if(!(dat & (1<<1))){    //按下按键2
			flag_key3 = 0;  //按键3按下标志位置0
			flag_key4 = 0;  //按键4按下标志位置0
			if(pressnum1 != 0){
				flag_key2 = 1;  //按键2按下标识符置1
			}
			timer_init(0,65,4,62500,0);    //设置定时器定时1s
		}else if(!(dat & (1<<2))){	  //按下按键3
			flag_key2 = 0;  //按键2按下标志位置0
			flag_key4 = 0;  //按键4按下标志位置0
			flag_key3 = 1;  //按键3按下标志位置1
			
			if(pressnum3 == 0){  //若为第一次按键
				flag_firstpress = 1;  //首次按键标志位置1
			}else{
				flag_firstpress = 0;  //首次按键标志位置0
			}
			
			if((flag_over == 0) && (flag_OT == 0) && (flag_firstpress == 0)){  //若不为首次按键且按键操作未结束未超时
				timenum = TCNTB0;  //获取计时器时间参数
				if(timenum > 0){
					if(key3_times == 0){  //若还是第一个计时周期
						delay(800000);
						pressnum3++;  //统计按键3按下次数
						flag_over = 0;  //按键结束标志位置0
						timer_init(0,65,4,125000,0);    //设置定时器定时2s
						flag_OT = 0;  //按键超时标志位置0
						key3_times = 0;  //计时器执行次数归0
						continue;  //进行下一次按键
					}
				}
			}else if((flag_over == 0) && (flag_OT == 0) && (flag_firstpress == 1)){  //若为首次按键且按键操作未结束未超时
				delay(800000);
				pressnum3++;  //统计按键3按下次数
				flag_over = 0;  //按键结束标志位置0
				timer_init(0,65,4,125000,0);    //设置定时器定时2s
				flag_OT = 0;  //按键超时标志位置0
				continue;  //进行下一次按键
			}
		}else if(!(dat & (1<<3))){	  //按下按键4，重置所有状态
			flag_key2 = 0;  //按键2按下标志位置0
			flag_key3 = 0;  //按键3按下标志位置0
			flag_key4 = 0;  //按键4按下标志位置0
			flag_OT = 0;  //按键超时标志位置0
			flag_over = 0;  //按键结束标志位置0
			equal_13 = 0;  //按键相等标志位置0
			flag_firstpress = 0;  //首次按键标志位置0
			key3_times = 0;  //计时器执行次数归0
			pressnum1 = 0;  //按键1按下次数归0
			pressnum3 = 0;  //按键3按下次数归0
			sharknum = 0;  //灯闪烁次数归0
			GPKDATA = 0xff;  //关灯
			buzzer_off();  //关蜂鸣器
			TINT_CSTAT |= (1<<0);  //关定时器
			TINT_CSTAT &= ~(1<<0);
			timer_init(0,65,4,62500,0);  //定时器初始化
		}
		if(sharknum == 2*pressnum1){  //若闪烁次数等于按键1按下次数
			flag_key2 = 0;  //按键2按下标志位置0
		}
	}
	
	return 0;
}
